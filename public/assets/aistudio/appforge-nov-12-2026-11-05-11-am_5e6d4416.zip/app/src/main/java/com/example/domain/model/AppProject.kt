package com.example.domain.model

/**
 * كيانات المشروع لنظام ApkForge المتطابق مع الفيديو
 */

enum class SourceType(val titleAr: String, val descAr: String) {
    HTML_FOLDER("ملف HTML", "مستند html واحد"),
    ZIP_ARCHIVE("موقع مضغوط", "ملف zip يحتوي على index.html"),
    WEB_URL("رابط ويب (URL)", "تحويل موقع ويب مباشر إلى تطبيق"),
    KOTLIN_TEMPLATE("قالب Kotlin", "تطبيق أندرويد متقدم")
}

data class SplashConfig(
    val enabled: Boolean = true,
    val backgroundColorHex: String = "#0F1318",
    val fadeBackground: Boolean = false,
    val indicatorStyle: String = "حلقة", // بدون، حلقة، شريط، حلقة - L، حلقة - S، نبض
    val iconSizeDp: Int = 120,
    val iconCornerRadiusDp: Int = 16,
    val indicatorSizeDp: Int = 48,
    val spacingDp: Int = 28
)

data class OnboardingSlide(
    val title: String,
    val description: String,
    val iconName: String = "bolt",
    val imageUri: String? = null
)

data class OnboardingConfig(
    val enabled: Boolean = false,
    val slides: List<OnboardingSlide> = listOf(
        OnboardingSlide("العنوان", "الوصف", "bolt")
    ),
    val layoutType: String = "بطاقة سفلية",
    val imageShape: String = "دائرة",
    val gradientBackground: Boolean = false,
    val accentColorHex: String = "#FFE236",
    val textColorHex: String = "#111827",
    val cardColorHex: String = "#FFFFFF",
    val showSkipButton: Boolean = true
)

data class PageLoaderConfig(
    val enabled: Boolean = false,
    val style: String = "حلقة", // حلقة، شريط، حلقة بالشعار، شريط بالشعار
    val sizeDp: Int = 78,
    val thicknessDp: Int = 7,
    val showOnCard: Boolean = true,
    val cardColorHex: String = "#FFFFFF",
    val cardOpacityPercent: Int = 100,
    val cardCornerRadiusDp: Int = 12
)

data class WebViewConfig(
    val fullScreen: Boolean = false,
    val pullToRefresh: Boolean = false,
    val pageLoader: PageLoaderConfig = PageLoaderConfig(),
    val supportZoom: Boolean = false,
    val cacheEnabled: Boolean = true,
    val fileDownload: Boolean = true,
    val offlineFallback: Boolean = true
)

data class BottomNavDestination(
    val id: String,
    val title: String,
    val targetUrl: String,
    val iconName: String = "home"
)

data class BottomNavConfig(
    val enabled: Boolean = false,
    val destinations: List<BottomNavDestination> = listOf(
        BottomNavDestination("1", "Home", "/")
    ),
    val barStyle: String = "مسطح",
    val showLabels: Boolean = true,
    val activeColorHex: String = "#FF7A2F",
    val inactiveColorHex: String = "#9CA3AF",
    val barColorHex: String = "#FFFFFF"
)

data class PackageConfig(
    val packageName: String = "com.zk.app",
    val versionName: String = "1.0",
    val versionCode: Int = 1,
    val minSdk: Int = 24,
    val targetSdk: Int = 34
)

data class PermissionsConfig(
    val camera: Boolean = false, // التقاط الصور عبر <input type="file">
    val location: Boolean = false, // طلبات تحديد الموقع من صفحاتك
    val microphone: Boolean = false, // مكالمات صوتية ومنزلة عبر getUserMedia
    val storage: Boolean = true,
    val notifications: Boolean = true
)

data class PushNotificationConfig(
    val enabled: Boolean = false,
    val provider: String = "OneSignal",
    val appId: String = ""
)

data class SigningKeyConfig(
    val useDebugKey: Boolean = true,
    val keyAlias: String = "apkforge_key",
    val keystorePath: String = ""
)

enum class BuildStatus {
    IDLE,
    PREPARING,
    BUILDING,
    SUCCESS,
    FAILED
}

data class AppProject(
    val id: String,
    val name: String,
    val description: String = "",
    val iconName: String = "default_app",
    val iconImageUri: String? = null,
    val primaryColorHex: String = "#FF7A2F",
    val accentColorHex: String = "#FF7A2F",
    val sourceType: SourceType = SourceType.ZIP_ARCHIVE,
    val sourceValue: String = "MegaEditor_New.zip",
    val splashConfig: SplashConfig = SplashConfig(),
    val onboardingConfig: OnboardingConfig = OnboardingConfig(),
    val webViewConfig: WebViewConfig = WebViewConfig(),
    val bottomNavConfig: BottomNavConfig = BottomNavConfig(),
    val packageConfig: PackageConfig = PackageConfig(),
    val permissionsConfig: PermissionsConfig = PermissionsConfig(),
    val pushConfig: PushNotificationConfig = PushNotificationConfig(),
    val signingConfig: SigningKeyConfig = SigningKeyConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val lastBuiltAt: Long? = null,
    val lastBuildStatus: BuildStatus = BuildStatus.IDLE,
    val lastOutputApk: String? = null
)
