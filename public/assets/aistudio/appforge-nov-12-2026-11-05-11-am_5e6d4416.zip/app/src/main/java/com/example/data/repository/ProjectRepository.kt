package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class DownloadedApk(
    val id: String,
    val projectName: String,
    val fileName: String,
    val filePath: String,
    val sizeText: String,
    val downloadedAt: Long
)

class ProjectRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("apkforge_projects_prefs", Context.MODE_PRIVATE)

    private val _projects = MutableStateFlow<List<AppProject>>(emptyList())
    val projects: StateFlow<List<AppProject>> = _projects.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadedApk>>(emptyList())
    val downloads: StateFlow<List<DownloadedApk>> = _downloads.asStateFlow()

    init {
        loadProjects()
    }

    private fun loadProjects() {
        val jsonString = prefs.getString("saved_projects", null)
        if (jsonString.isNullOrBlank()) {
            _projects.value = emptyList()
        } else {
            try {
                val array = JSONArray(jsonString)
                val list = mutableListOf<AppProject>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val proj = parseProject(obj)
                    // Filter out any previous fake "Rio" project
                    if (proj.id != "proj_rio_001" && proj.name != "Rio") {
                        list.add(proj)
                    }
                }
                _projects.value = list
                saveToPrefs(list)
            } catch (e: Exception) {
                _projects.value = emptyList()
            }
        }
    }

    fun saveProject(project: AppProject) {
        val current = _projects.value.toMutableList()
        val index = current.indexOfFirst { it.id == project.id }
        if (index >= 0) {
            current[index] = project
        } else {
            current.add(0, project)
        }
        _projects.value = current
        saveToPrefs(current)
    }

    fun deleteProject(projectId: String) {
        val current = _projects.value.filter { it.id != projectId }
        _projects.value = current
        saveToPrefs(current)
    }

    fun getProjectById(id: String): AppProject? {
        return _projects.value.find { it.id == id }
    }

    fun addDownloadedApk(apk: DownloadedApk) {
        val current = _downloads.value.toMutableList()
        current.add(0, apk)
        _downloads.value = current
    }

    fun updateBuildStatus(projectId: String, status: BuildStatus, apkPath: String?) {
        val project = getProjectById(projectId) ?: return
        val updated = project.copy(
            lastBuildStatus = status,
            lastBuiltAt = System.currentTimeMillis(),
            lastOutputApk = apkPath ?: project.lastOutputApk
        )
        saveProject(updated)
        if (status == BuildStatus.SUCCESS && apkPath != null) {
            addDownloadedApk(
                DownloadedApk(
                    id = "dl_${System.currentTimeMillis()}",
                    projectName = project.name,
                    fileName = "${project.name}_v${project.packageConfig.versionName}.apk",
                    filePath = apkPath,
                    sizeText = "8.4 MB",
                    downloadedAt = System.currentTimeMillis()
                )
            )
        }
    }

    private fun saveToPrefs(list: List<AppProject>) {
        val array = JSONArray()
        list.forEach { proj ->
            val obj = JSONObject().apply {
                put("id", proj.id)
                put("name", proj.name)
                put("description", proj.description)
                put("iconName", proj.iconName)
                put("primaryColorHex", proj.primaryColorHex)
                put("accentColorHex", proj.accentColorHex)
                put("sourceType", proj.sourceType.name)
                put("sourceValue", proj.sourceValue)
                put("packageName", proj.packageConfig.packageName)
                put("versionName", proj.packageConfig.versionName)
                put("versionCode", proj.packageConfig.versionCode)
                put("lastBuildStatus", proj.lastBuildStatus.name)
                put("lastBuiltAt", proj.lastBuiltAt ?: 0L)
                put("lastOutputApk", proj.lastOutputApk ?: "")
                put("createdAt", proj.createdAt)
            }
            array.put(obj)
        }
        prefs.edit().putString("saved_projects", array.toString()).apply()
    }

    private fun parseProject(obj: JSONObject): AppProject {
        val stName = obj.optString("sourceType", SourceType.ZIP_ARCHIVE.name)
        val st = try { SourceType.valueOf(stName) } catch (e: Exception) { SourceType.ZIP_ARCHIVE }
        val statusName = obj.optString("lastBuildStatus", BuildStatus.IDLE.name)
        val bs = try { BuildStatus.valueOf(statusName) } catch (e: Exception) { BuildStatus.IDLE }

        return AppProject(
            id = obj.getString("id"),
            name = obj.getString("name"),
            description = obj.optString("description", ""),
            iconName = obj.optString("iconName", "default_app"),
            primaryColorHex = obj.optString("primaryColorHex", "#FF7A2F"),
            accentColorHex = obj.optString("accentColorHex", "#FF7A2F"),
            sourceType = st,
            sourceValue = obj.optString("sourceValue", "MegaEditor_New.zip"),
            packageConfig = PackageConfig(
                packageName = obj.optString("packageName", "com.zk.app"),
                versionName = obj.optString("versionName", "1.0"),
                versionCode = obj.optInt("versionCode", 1)
            ),
            lastBuildStatus = bs,
            lastBuiltAt = if (obj.has("lastBuiltAt") && obj.getLong("lastBuiltAt") > 0L) obj.getLong("lastBuiltAt") else null,
            lastOutputApk = obj.optString("lastOutputApk").takeIf { !it.isNullOrBlank() },
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
        )
    }
}
