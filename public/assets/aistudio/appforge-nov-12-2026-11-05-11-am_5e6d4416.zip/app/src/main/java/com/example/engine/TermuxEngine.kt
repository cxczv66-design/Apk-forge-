package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.domain.model.AppProject
import com.example.domain.model.SourceType
import com.example.utils.Constants
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * المحرك البرمجي المسؤول عن التواصل مع تطبيق Termux
 * وبناء أوامر Bash وتنفيذ عمليات البناء المتقدمة
 */
class TermuxEngine(private val context: Context) {

    sealed class EngineStatus {
        data object Idle : EngineStatus()
        data class Running(val progress: Float, val currentTask: String) : EngineStatus()
        data class Success(val apkPath: String, val message: String) : EngineStatus()
        data class Failure(val error: String, val detailedLogs: String) : EngineStatus()
    }

    private val _engineState = MutableStateFlow<EngineStatus>(EngineStatus.Idle)
    val engineState: StateFlow<EngineStatus> = _engineState.asStateFlow()

    private val _logStream = MutableStateFlow<List<String>>(emptyList())
    val logStream: StateFlow<List<String>> = _logStream.asStateFlow()

    /**
     * فحص هل تطبيق Termux مثبت على الهاتف
     */
    fun isTermuxInstalled(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    Constants.TERMUX_PACKAGE_NAME,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(Constants.TERMUX_PACKAGE_NAME, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * فحص صلاحية إرسال الأوامر RUN_COMMAND
     */
    fun hasRunCommandPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Constants.TERMUX_PERMISSION_RUN_COMMAND
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * بناء سكربت Bash متكامل لبناء المشروع داخل Termux
     */
    fun generateBashBuildScript(project: AppProject, buildType: String = "debug"): String {
        val sanitizedProjectName = project.name.replace(Regex("[^a-zA-Z0-9_]"), "_")
        val pkg = project.packageConfig.packageName
        val versionCode = project.packageConfig.versionCode
        val versionName = project.packageConfig.versionName
        val workDir = "\$HOME/${Constants.WORKSPACE_SUBDIR}/$sanitizedProjectName"
        val outFileName = "${sanitizedProjectName}_v${versionName}_$buildType.apk"
        val targetDownload = "${Constants.DOWNLOADS_DIR}/$outFileName"

        val gradleCommand = if (buildType.equals("release", ignoreCase = true)) {
            "gradle assembleRelease"
        } else if (buildType.equals("aab", ignoreCase = true)) {
            "gradle bundleRelease"
        } else {
            "gradle assembleDebug"
        }

        val relativeApkOut = if (buildType.equals("release", ignoreCase = true)) {
            "app/build/outputs/apk/release/app-release-unsigned.apk"
        } else if (buildType.equals("aab", ignoreCase = true)) {
            "app/build/outputs/bundle/release/app-release.aab"
        } else {
            "app/build/outputs/apk/debug/app-debug.apk"
        }

        return """
            #!/data/data/com.termux/files/usr/bin/bash
            # ========================================================
            # 🚀 AppForge Engine - سكريبت البناء الأوتوماتيكي داخل Termux
            # المشروع: ${project.name}
            # الحزمة: $pkg
            # النوع: $buildType
            # ========================================================
            
            set -e
            echo "[1/6] 🔧 تهيئة مجلد المشروع والبيئة..."
            PROJECT_DIR="$workDir"
            mkdir -p "${'$'}PROJECT_DIR/app/src/main/java/${pkg.replace('.', '/')}"
            mkdir -p "${'$'}PROJECT_DIR/app/src/main/res/values"
            mkdir -p "${'$'}PROJECT_DIR/app/src/main/assets"
            cd "${'$'}PROJECT_DIR"
            
            echo "[2/6] 📦 حقن إعدادات التطبيق والأذونات..."
            # توليد AndroidManifest.xml
            cat << 'EOF' > app/src/main/AndroidManifest.xml
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android"
                package="$pkg">
                ${if (project.permissionsConfig.camera) "<uses-permission android:name=\"android.permission.CAMERA\" />" else ""}
                ${if (project.permissionsConfig.location) "<uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />" else ""}
                ${if (project.permissionsConfig.microphone) "<uses-permission android:name=\"android.permission.RECORD_AUDIO\" />" else ""}
                ${if (project.permissionsConfig.storage) "<uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\" />" else ""}
                <uses-permission android:name="android.permission.INTERNET" />
                <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
                <application
                    android:allowBackup="true"
                    android:label="${project.name}"
                    android:supportsRtl="true"
                    android:theme="@android:style/Theme.Material.Light.NoActionBar">
                    <activity
                        android:name=".MainActivity"
                        android:exported="true"
                        android:configChanges="orientation|screenSize|keyboardHidden">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
            EOF
            
            echo "[3/6] 🌐 نسخ الأصول والمصادر (${project.sourceType.name})..."
            ${when (project.sourceType) {
                SourceType.WEB_URL -> """
                cat << 'EOF' > app/src/main/assets/app_config.json
                {
                   "url": "${project.sourceValue}",
                   "pullToRefresh": ${project.webViewConfig.pullToRefresh},
                   "fullScreen": ${project.webViewConfig.fullScreen},
                   "cache": ${project.webViewConfig.cacheEnabled}
                }
                EOF
                """.trimIndent()
                SourceType.HTML_FOLDER -> """
                echo "<h1>مرحباً بك في ${project.name}</h1>" > app/src/main/assets/index.html
                """.trimIndent()
                else -> """
                echo "مصدر مخصص: ${project.sourceValue}" > app/src/main/assets/source.txt
                """.trimIndent()
            }}
            
            echo "[4/6] ⚙️ تشغيل محرك البناء والتجميع ($gradleCommand)..."
            if command -v gradle &> /dev/null; then
                $gradleCommand --no-daemon
            else
                echo "⚠️ تنبيه: Gradle غير مثبت في Termux، يرجى تشغيل: pkg install openjdk-17 gradle"
                exit 1
            fi
            
            echo "[5/6] 🔐 التوقيع ونقل ملف الإخراج..."
            if [ -f "$relativeApkOut" ]; then
                mkdir -p "${Constants.DOWNLOADS_DIR}"
                cp "$relativeApkOut" "$targetDownload"
                echo "========================================================"
                echo "✅ اكتمل البناء بنجاح!"
                echo "📱 تم حفظ التطبيق في: $targetDownload"
                echo "========================================================"
            else
                echo "❌ خطأ: لم يتم العثور على ملف الإخراج: $relativeApkOut"
                exit 1
            fi
        """.trimIndent()
    }

    /**
     * إرسال الأمر إلى Termux عبر Intent
     */
    fun dispatchBuildToTermux(
        project: AppProject,
        buildType: String = "debug",
        onDirectIntentSent: () -> Unit
    ) {
        val bashScript = generateBashBuildScript(project, buildType)
        
        try {
            val intent = Intent(Constants.TERMUX_ACTION_RUN_COMMAND).apply {
                setClassName(Constants.TERMUX_PACKAGE_NAME, "com.termux.app.RunCommandService")
                putExtra(Constants.EXTRA_COMMAND_PATH, Constants.TERMUX_BASH_PATH)
                putExtra(Constants.EXTRA_ARGUMENTS, arrayOf("-c", bashScript))
                putExtra(Constants.EXTRA_WORKDIR, Constants.TERMUX_HOME_DIR)
                putExtra(Constants.EXTRA_BACKGROUND, false)
                putExtra(Constants.EXTRA_SESSION_ACTION, "0")
            }
            
            context.startService(intent)
            addLog("🚀 تم إرسال أمر البناء بنجاح إلى خدمة Termux RunCommandService")
            onDirectIntentSent()
        } catch (e: Exception) {
            addLog("⚠️ تعذر تشغيل خدمة Termux المباشرة: ${e.message}")
            // محاولة فتح Termux كواجهة أو إطلاق بديل
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(Constants.TERMUX_PACKAGE_NAME)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    addLog("ℹ️ تم فتح تطبيق Termux للتنفيذ اليدوي.")
                }
            } catch (ignored: Exception) {
            }
        }
    }

    /**
     * محاكاة وتنفيذ تجريبي متكامل مع بث السجلات خطوة بخطوة للواجهة
     */
    suspend fun executeBuildWithProgress(
        project: AppProject,
        buildType: String = "debug"
    ): Boolean {
        _logStream.value = emptyList()
        _engineState.value = EngineStatus.Running(0.05f, "تهيئة مساحة العمل...")
        
        addLog("🚀 [AppForge Studio] بدء عملية البناء لمشروع: ${project.name}")
        addLog("📦 اسم الحزمة: ${project.packageConfig.packageName}")
        addLog("🔢 رقم الإصدار: ${project.packageConfig.versionName} (${project.packageConfig.versionCode})")
        addLog("🎯 وضع البناء: $buildType")
        delay(600)

        _engineState.value = EngineStatus.Running(0.20f, "توليد ملفات المشروع والأذونات...")
        addLog("⚙️ توليد AndroidManifest.xml والأذونات المطلوبة...")
        if (project.permissionsConfig.camera) addLog("  └ إضافة إذن: android.permission.CAMERA")
        if (project.permissionsConfig.location) addLog("  └ إضافة إذن: android.permission.ACCESS_FINE_LOCATION")
        if (project.permissionsConfig.storage) addLog("  └ إضافة إذن: android.permission.READ_EXTERNAL_STORAGE")
        addLog("  └ إضافة إذن: android.permission.INTERNET")
        delay(700)

        _engineState.value = EngineStatus.Running(0.40f, "معالجة أصول الويب والواجهات...")
        addLog("🌐 معالجة المصدر [${project.sourceType.titleAr}]...")
        addLog("  └ الرابط/المسار: ${project.sourceValue}")
        addLog("  └ إعدادات WebView: PullToRefresh=${project.webViewConfig.pullToRefresh}, FullScreen=${project.webViewConfig.fullScreen}")
        if (project.bottomNavConfig.enabled) {
            addLog("  └ حقن الشريط السفلي: ${project.bottomNavConfig.destinations.size} عناصر")
        }
        delay(800)

        _engineState.value = EngineStatus.Running(0.65f, "تشغيل أدوات الترجمة AAPT2 & D8...")
        addLog("🔨 ترجمة الموارد عبر aapt2 compile & link...")
        addLog("⚡ تحويل أكواد بايتكود عبر D8 / R8 Compiler...")
        delay(900)

        _engineState.value = EngineStatus.Running(0.85f, "توقيع الحزمة عبر ApkSigner...")
        if (project.signingConfig.useDebugKey) {
            addLog("🔑 توقيع الحزمة باستخدام مفتاح Debug الافتراضي...")
        } else {
            addLog("🔐 توقيع الحزمة باستخدام مفتاح Keystore مخصص...")
        }
        delay(700)

        _engineState.value = EngineStatus.Running(0.95f, "نسخ ملف APK إلى مجلد التنزيلات...")
        val outFileName = "${project.name.replace(' ', '_')}_v${project.packageConfig.versionName}_$buildType.apk"
        val downloadPath = "${Constants.DOWNLOADS_DIR}/$outFileName"
        addLog("📁 نقل الناتج النهائي إلى: $downloadPath")
        delay(500)

        _engineState.value = EngineStatus.Success(
            apkPath = downloadPath,
            message = "تم بناء التطبيق وتوقيعه بنجاح!"
        )
        addLog("========================================================")
        addLog("🎉 اكتمل البناء بنجاح في 3.7 ثانية!")
        addLog("📲 ملف APK جاهز للتثبيت والمشاركة: $outFileName")
        addLog("========================================================")
        return true
    }

    fun resetState() {
        _engineState.value = EngineStatus.Idle
    }

    private fun addLog(line: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        val updated = _logStream.value.toMutableList()
        updated.add("[$timestamp] $line")
        _logStream.value = updated
    }
}
