package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.model.AppProject
import com.example.domain.model.PackageConfig
import com.example.domain.model.SourceType
import com.example.engine.TermuxEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class TermuxEngineTest {

    @Test
    fun `generateBashBuildScript contains project name and gradle command`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = TermuxEngine(context)

        val project = AppProject(
            id = "test_01",
            name = "Rio",
            sourceType = SourceType.WEB_URL,
            sourceValue = "https://rio-store.example.com",
            packageConfig = PackageConfig(
                packageName = "com.rio.app",
                versionName = "1.0.0"
            )
        )

        val script = engine.generateBashBuildScript(project, "debug")
        assertTrue(script.contains("Rio"))
        assertTrue(script.contains("com.rio.app"))
        assertTrue(script.contains("gradle assembleDebug"))
        assertTrue(script.contains("appforge_workspace"))
    }
}
